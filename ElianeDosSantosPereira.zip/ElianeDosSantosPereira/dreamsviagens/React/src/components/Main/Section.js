import Aside from '../Aside/Aside';
import '../Main/Main.css';

function Section(){
    return(
        <Aside></Aside>
    );
}
export default Section;