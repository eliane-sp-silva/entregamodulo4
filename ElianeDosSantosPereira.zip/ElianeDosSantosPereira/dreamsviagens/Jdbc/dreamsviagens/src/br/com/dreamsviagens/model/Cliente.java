package br.com.dreamsviagens.model;


public class Cliente {
	private int ID_Cliente;
	private String Cpf;
	private String NomeCliente;
	private String Email;
	private String DtNascimento;
	private String CidadeCliente;
	private String EstadoCliente;
	
	
	
	public Cliente() {
		super();
		// TODO Auto-generated constructor stub
	}



	public int getID_Cliente() {
		return ID_Cliente;
	}



	public String getCpf() {
		return Cpf;
	}



	public String getNomeCliente() {
		return NomeCliente;
	}



	public String getEmail() {
		return Email;
	}



	public String getDtNascimento() {
		return DtNascimento;
	}



	public String getCidadeCliente() {
		return CidadeCliente;
	}



	public String getEstadoCliente() {
		return EstadoCliente;
	}



	public void setID_Cliente(int iD_Cliente) {
		this.ID_Cliente = iD_Cliente;
	}



	public void setCpf(String cpf) {
		this.Cpf = cpf;
	}



	public void setNomeCliente(String nomeCliente) {
		this.NomeCliente = nomeCliente;
	}



	public void setEmail(String email) {
		this.Email = email;
	}



	public void setDtNascimento(String dtNascimento) {
		this.DtNascimento = dtNascimento;
	}



	public void setCidadeCliente(String cidadeCliente) {
		this.CidadeCliente = cidadeCliente;
	}



	public void setEstadoCliente(String estadoCliente) {
		this.EstadoCliente = estadoCliente;
	}

	
	
}
