import '../Footer/Footer.css';
import { Link } from "react-router-dom";

function ColumnThree(){
    return(
        <div class="item ">    

            <h2>Links</h2>
            <div class="box h-box">
            <Link to="/" className="text-decoration-none ">Home</Link>            
            <Link to="/Destinos" className="text-decoration-none">Destinos</Link>
            <Link to="/Promocao"className="text-decoration-none">Promoções</Link>
            <Link to="/Contato"className="text-decoration-none">Contato</Link>
            <Link to="/Login"className="text-decoration-none">Login</Link>         

        </div>
    </div>
    );
}
export default ColumnThree;