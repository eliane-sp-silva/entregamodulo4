import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Home from '../src/Pages/Home/Home';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Contato from './Pages/Contato/Contato';
import Promocao from './Pages/Promocao/Promocao';
import Login from './Pages/Login/Login'
import Destinos from './Pages/Destinos/Destinos';
import ContatoLottie from './components/ContatoLottie/ContatoLottie';


ReactDOM.render(
  <React.StrictMode>
    <Router>
      <Routes>
        <Route exact path="/" element={ <Home/> }></Route>
        <Route path="/Destinos" element={ <Destinos/> }></Route>
        <Route path="/Promocao" element={ <Promocao/> }></Route>        
        <Route path="/Contato" element={ <Contato/> }></Route>
        <Route path="/Login" element={ <Login/> }></Route>
                

      </Routes>
    </Router>
    
  </React.StrictMode>,
  document.getElementById('root')
);


