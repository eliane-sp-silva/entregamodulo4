import Header from '../../components/Header/Header';
import Footer from '../../components/Footer/Footer';
import Contatos from '../../components/FormContato/Contatos';
// import FormContato from '../../components/FormContato/FormContato';


function Contato(){
    return(
       <>
            <Header></Header>
            <Contatos></Contatos>            
            <Footer></Footer>
       </>
     
);
}

export default Contato;