package br.com.dreamsviagens.application;

import br.com.dreamsviagens.dao.ClienteDAO;
import br.com.dreamsviagens.model.Cliente;

public class Main {

	public static void main(String[] args) {

		ClienteDAO clienteDAO = new ClienteDAO();
		Cliente cliente = new Cliente();
		
		/*
		//METODO CREATE		
		cliente.setCpf("34534534545");
		cliente.setNomeCliente("Jo�o Silva");
		cliente.setEmail("joao@gmail.com");
		cliente.setDtNascimento("19800821");
		cliente.setCidadeCliente("S�o Roque");
		cliente.setEstadoCliente("SP");

		clienteDAO.Salvar(cliente);
		
	
		//METODO READ
		for (Cliente c : clienteDAO.ListarClientes()) {
			System.out.println("NOME: " + c.getNomeCliente());
		}
		*/
		
		//METODO UPDATE
		Cliente cliente1 = new Cliente();
		cliente1.setID_Cliente(3);
		cliente1.setCpf(null);
		cliente1.setNomeCliente("Jo�o Cardoso Silva");
		cliente1.setEmail(null);
		cliente1.setDtNascimento(null);
		cliente1.setCidadeCliente("Cotia");
		cliente1.setEstadoCliente(null);
		
		/*
		//METODO DELETE
		clienteDAO.ExcluirID(1);
	*/
		
	}

}
